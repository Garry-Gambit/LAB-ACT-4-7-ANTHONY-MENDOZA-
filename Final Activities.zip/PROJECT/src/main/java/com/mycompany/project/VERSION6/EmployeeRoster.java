/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.project.VERSION6;

import java.util.ArrayList;
import java.util.List;

public class EmployeeRoster {
    private List<Employee> empList;

    public EmployeeRoster() {
        this.empList = new ArrayList<>();
    }

    public boolean addEmployee(Employee e) {
        return empList.add(e);  
    }

    public Employee removeEmployee(int ID) {
        for (Employee employee : empList) {
            if (employee.getID() == ID) {
                empList.remove(employee);
                return employee;  
            }
        }
        return null;  
    }

    public int getCount() {
        return empList.size();
    }

    public void displayEmployees() {
        System.out.print("ID\t");
        System.out.print("Name\t\t\t");
        System.out.print("Date Joined\t");
        System.out.print("Birth Date\t");
        System.out.print("Salary\t\t");
        System.out.print("Employee Type\t\n");

        for (Employee employee : empList) {
            System.out.print(employee.getID() + "\t");
            System.out.print(employee.getName() + "\t");
            System.out.print(employee.getHireDate() + "\t");
            System.out.print(employee.getDateOfBirth() + "\t");

            if (employee instanceof HourlyEmployee) {
                System.out.print(((HourlyEmployee) employee).computeSalary() + "\t\t");
                System.out.println("Hourly Employee");
            } else if (employee instanceof PieceWorkerEmployee) {
                System.out.print(((PieceWorkerEmployee) employee).computeSalary() + "\t\t");
                System.out.println("PieceWorkerEmployee");
            } else if (employee instanceof CommisionEmployee) {
                System.out.print(((CommisionEmployee) employee).computeSalary() + "\t\t");
                System.out.println("CommisionEmployee");
            } else if (employee instanceof BasedPlusCommisionEmployee) {
                System.out.print(((BasedPlusCommisionEmployee) employee).computeSalary() + "\t\t");
                System.out.println("BasedPlusCommisionEmployee");
            }
        }
    }

    public void displayHourly() {
        System.out.print("ID\t");
        System.out.print("Name\t\t\t");
        System.out.print("Date Joined\t");
        System.out.print("Birth Date\t");
        System.out.print("Salary\t\t");
        System.out.print("Employee Type\t\n");

        for (Employee employee : empList) {
            if (employee instanceof HourlyEmployee) {
                System.out.print(employee.getID() + "\t");
                System.out.print(employee.getName() + "\t");
                System.out.print(employee.getHireDate() + "\t");
                System.out.print(employee.getDateOfBirth() + "\t");
                System.out.print(((HourlyEmployee) employee).computeSalary() + "\t\t");
                System.out.println("Hourly Employee");
            }
        }
    }

    public void displayPieceWorker() {
        System.out.print("ID\t");
        System.out.print("Name\t\t\t");
        System.out.print("Date Joined\t");
        System.out.print("Birth Date\t");
        System.out.print("Salary\t\t");
        System.out.print("Employee Type\t\n");

        for (Employee employee : empList) {
            if (employee instanceof PieceWorkerEmployee) {
                System.out.print(employee.getID() + "\t");
                System.out.print(employee.getName() + "\t");
                System.out.print(employee.getHireDate() + "\t");
                System.out.print(employee.getDateOfBirth() + "\t");
                System.out.print(((PieceWorkerEmployee) employee).computeSalary() + "\t\t");
                System.out.println("PieceWorkerEmployee");
            }
        }
    }

    public void displayCommisionEmployee() {
        System.out.print("ID\t");
        System.out.print("Name\t\t\t");
        System.out.print("Date Joined\t");
        System.out.print("Birth Date\t");
        System.out.print("Salary\t\t");
        System.out.print("Employee Type\t\n");

        for (Employee employee : empList) {
            if (employee instanceof CommisionEmployee) {
                System.out.print(employee.getID() + "\t");
                System.out.print(employee.getName() + "\t");
                System.out.print(employee.getHireDate() + "\t");
                System.out.print(employee.getDateOfBirth() + "\t");
                System.out.print(((CommisionEmployee) employee).computeSalary() + "\t\t");
                System.out.println("CommisionEmployee");
            }
        }
    }

    public void displayBasedPlusCommision() {
        System.out.print("ID\t");
        System.out.print("Name\t\t\t");
        System.out.print("Date Joined\t");
        System.out.print("Birth Date\t");
        System.out.print("Salary\t\t");
        System.out.print("Employee Type\t\n");

        for (Employee employee : empList) {
            if (employee instanceof BasedPlusCommisionEmployee) {
                System.out.print(employee.getID() + "\t");
                System.out.print(employee.getName() + "\t");
                System.out.print(employee.getHireDate() + "\t");
                System.out.print(employee.getDateOfBirth() + "\t");
                System.out.print(((BasedPlusCommisionEmployee) employee).computeSalary() + "\t\t");
                System.out.println("BasedPlusCommisionEmployee");
            }
        }
    }
}
