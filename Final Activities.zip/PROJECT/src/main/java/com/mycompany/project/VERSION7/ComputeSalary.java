package com.mycompany.project.VERSION7;

public interface ComputeSalary {
    double computeSalary();
}
